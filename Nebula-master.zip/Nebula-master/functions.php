<?php
/**
 * Functions
 */

require_once 'nebula.php';
nebula();

//Close functions.php. DO NOT add anything after this closing tag!! ?>