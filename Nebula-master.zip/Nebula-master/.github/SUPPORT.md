# Nebula Support

Nebula does not have an official support platform. Feel free to tag me in a question on the [WordPress StackExchange](https://wordpress.stackexchange.com/users/48966/greatblakes?tab=profile) or use Github issues here if preferred.

* [Documentation](https://gearside.com/nebula/)
* [Bug Reporting/Feature Requests](https://github.com/chrisblakley/Nebula/issues)