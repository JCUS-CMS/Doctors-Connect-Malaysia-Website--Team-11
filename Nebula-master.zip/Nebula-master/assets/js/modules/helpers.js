nebula.example = function(){
	//console.log('This is an example.');
};